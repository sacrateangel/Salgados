import React, { useState } from "react";
import "./App.css";

const salgados = [
  { nome: "Rissóis de carne", imagem: "/images/rissois-carne.jpg" },
  { nome: "Rissóis de atum", imagem: "/images/rissois-atum.jpg" },
  { nome: "Rissóis de camarão", imagem: "/images/rissois-camarao.jpg" },
  { nome: "Rissóis de pizza", imagem: "/images/rissois-pizza.jpg" },
  { nome: "Rissóis de pescada", imagem: "/images/rissois-pescada.jpg" },
  { nome: "Rissóis de legumes", imagem: "/images/rissois-legumes.jpg" },
  { nome: "Croquete de carne", imagem: "/images/croquete-carne.jpg" },
  { nome: "Croquete de legumes", imagem: "/images/croquete-legumes.jpg" },
  { nome: "Coxinha de frango", imagem: "/images/coxinha-frango.jpg" },
  { nome: "Pastel de bacalhau", imagem: "/images/pastel-bacalhau.jpg" },
  { nome: "Chamuça com picante", imagem: "/images/chamuca-picante.jpg" },
  { nome: "Chamuça sem picante", imagem: "/images/chamuca-sem-picante.jpg" },
  { nome: "Almofadinha de queijo e fiambre", imagem: "/images/almofadinha-fiambre.jpg" },
  { nome: "Almofadinha de queijo e bacon", imagem: "/images/almofadinha-bacon.jpg" },
  { nome: "Rolinhos de salsicha", imagem: "/images/rolinho-salsicha.jpg" },
  { nome: "Bola de queijo e chouriço", imagem: "/images/bola-queijo-chourico.jpg" },
  { nome: "Bola de queijo", imagem: "/images/bola-queijo.jpg" },
  { nome: "Pastel de massa tenra de carne", imagem: "/images/pastel-massa-carne.jpg" },
  { nome: "Pastel de massa tenra de peixe", imagem: "/images/pastel-massa-peixe.jpg" },
  { nome: "Empada de frango", imagem: "/images/empada-frango.jpg" },
  { nome: "Empada de legumes", imagem: "/images/empada-legumes.jpg" }
];

function App() {
  const [search, setSearch] = useState("");

  const filtrados = salgados.filter(s =>
    s.nome.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="App">
      <header>
        <h1>Salgados da Tia Lena</h1>
        <p>Delícias artesanais para todas as ocasiões</p>
        <input
          placeholder="Pesquisar salgados..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </header>
      <div className="grid">
        {filtrados.map((s, idx) => (
          <div key={idx} className="card">
            <img src={s.imagem} alt={s.nome} />
            <h2>{s.nome}</h2>
          </div>
        ))}
      </div>
      <footer>
        <p>Encomendas: 939 136 155</p>
        <p>Email: helenacharraz@gmail.com</p>
      </footer>
    </div>
  );
}

export default App;